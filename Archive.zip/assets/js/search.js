export function findElementById(id) {
    // Return the element in the DOM with corresponding `id`
    // Initialize a queue with the root element
    let queue = [document.body];

    // Process elements in the queue one by one
    while (queue.length > 0) {
        const element = queue.shift();

        // Check if the current element matches the id
        if (element.id === id) {
            return element;
        }

        // Add all child elements to the queue
        for (let child of element.children) {
            queue.push(child);
        }
    }

    // Return null if the element is not found
    return null;
}

export function findFirstElementOfTag(tag) {
    // Return the first occurence of an element of tag name `tag`


        // Initialize a queue with the root element
        let queue = [document.body];

        // Process elements in the queue one by one
        while (queue.length > 0) {
            const element = queue.shift();

            // Check if the current element matches the tag name
            if (element.tagName.toLowerCase() === tag.toLowerCase()) {
                return element;
            }

            // Add all child elements to the queue
            for (let child of element.children) {
                queue.push(child);
            }
        }

        // Return null if no element with the tag is found
        return null;

}

export function findFirstElementOfClass(cls) {
    // Return the first occurence of an element of class `cls`

    let queue = [document.body];

    while (queue.length > 0) {

        const element = queue.shift();

        if (element.className === cls) {
            return element;
        }

        for (let child of element.children) {
            queue.push(child);
        }
    }

    return null;
}

export function findElementsOfTag(tag) {

    let queue = [document.body];
    let result = [];

    while (queue.length > 0) {

        const element = queue.shift();

        if (element.tagName.toLowerCase() === tag.toLowerCase()) {
            result.push(element);
        }

        for (let child of element.children) {
            queue.push(child);
        }
    }

    return result;
}

export function findElementsOfClass(cls) {

    let queue = [document.body];
    let result = [];

    while (queue.length > 0) {

        const element = queue.shift();

        if (element.className === cls) {
            result.push(element);
        }

        for (let child of element.children) {
            queue.push(child);
        }
    }

    return result;
}
