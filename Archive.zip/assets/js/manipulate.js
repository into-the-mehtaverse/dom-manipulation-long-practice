

export function changeTitle() {
    // Change the title of the page to "(Your name)'s Portfolio"

    document.title = "Shaan Mehta's Portfolio";
    return;
}

export function changeHeader() {
    // Change the name in the h1 of the page to your name
    const header = document.body.querySelector("h1");

    header.innerText = "Shaan Mehta";
}

export function changeAboutMe() {
    /* Update the first paragraph in the About Me section with a small
     passage about yourself */

     const h2Elements = document.querySelectorAll("h2");
     let aboutMeSection;

     for (let h2 of h2Elements) {
        if (h2.innerText === "About me") {
            aboutMeSection = h2.parentElement;
            break;
        }
     }

    const firstP = aboutMeSection.querySelector("p");
    firstP.innerText = "I left my lucrative job in commercial real estate to teach myself software engineering and pursue my dream of building a billion dollar company in this lifetime";

}
